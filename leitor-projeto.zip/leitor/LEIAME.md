# Leitor
1. Crie um repositório no GitHub e envie esta pasta (pode arrastar os arquivos pelo site).
2. Aba **Actions** → "Build APK" → quando terminar, baixe o artefato **leitor-apk**.
3. Descompacte, instale o `app-debug.apk` no celular (permita fontes desconhecidas).
4. Na primeira vez, aceite a permissão de notificações; ela mantém a leitura com a tela bloqueada.
5. Para resumo/estudo, cole sua chave da API da Anthropic no app.
