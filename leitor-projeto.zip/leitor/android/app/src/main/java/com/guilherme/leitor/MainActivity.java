package com.guilherme.leitor;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
