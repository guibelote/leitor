import * as pdfjs from 'pdfjs-dist/build/pdf';
import worker from 'pdfjs-dist/build/pdf.worker.min.js?url';
import { Capacitor } from '@capacitor/core';
import { TextToSpeech } from '@capacitor-community/text-to-speech';
import { ForegroundService } from '@capawesome-team/capacitor-android-foreground-service';

pdfjs.GlobalWorkerOptions.workerSrc = worker;
const $ = (id) => document.getElementById(id);
const native = Capacitor.isNativePlatform();
const MODEL = 'claude-sonnet-5-5';
let pages = [], cur = 0, name = '', playing = false, run = 0, ci = 0, chunks = [], voices = [];

// ---------- vozes ----------
(async () => {
  try {
    voices = (await TextToSpeech.getSupportedVoices()).voices || [];
    const pt = voices.map((v, i) => ({ v, i })).filter((x) => /^pt/i.test(x.v.lang));
    const list = pt.length ? pt : voices.map((v, i) => ({ v, i }));
    $('vz').innerHTML = list.map((x) => `<option value="${x.i}">${x.v.name}</option>`).join('');
  } catch (e) {}
})();
$('rate').oninput = (e) => ($('rv').textContent = (+e.target.value).toFixed(1) + 'x');

// ---------- PDF ----------
$('f').onchange = async (e) => {
  const file = e.target.files[0]; if (!file) return;
  await stop(); $('st').textContent = 'Lendo PDF…';
  try {
    const pdf = await pdfjs.getDocument({ data: await file.arrayBuffer() }).promise;
    pages = [];
    for (let i = 1; i <= pdf.numPages; i++) {
      const t = await (await pdf.getPage(i)).getTextContent();
      pages.push(t.items.map((x) => x.str).join(' ').replace(/\s+/g, ' ').trim());
      $('st').textContent = `Lendo ${i}/${pdf.numPages}…`;
    }
    name = file.name;
    $('st').textContent = `${name} — ${pdf.numPages} páginas` + (pages.join('').length < 50 ? ' (sem texto: PDF escaneado?)' : '');
    cur = Math.min(+(localStorage.getItem('p:' + name + ':' + file.size) || 0), pages.length - 1);
    window._pk = 'p:' + name + ':' + file.size;
    show(); $('rd').hidden = false; $('ai').hidden = false;
  } catch (err) { $('st').textContent = 'Erro ao ler o PDF.'; }
};
const split = (t) => (t.match(/[^.!?]+[.!?]*\s*/g) || []).flatMap((s) => (s.length > 220 ? s.match(/.{1,200}(\s|$)/g) : [s]));
function show() {
  $('pg').textContent = `${cur + 1}/${pages.length}`;
  chunks = split(pages[cur] || '');
  const box = $('txt'); box.textContent = '';
  chunks.forEach((c, i) => { const s = document.createElement('span'); s.id = 'c' + i; s.textContent = c; box.appendChild(s); });
  if (!chunks.length) box.textContent = '(página vazia)';
  try { localStorage.setItem(window._pk, cur); } catch (e) {}
}
function mark(i) {
  document.querySelectorAll('#txt span.on').forEach((s) => s.classList.remove('on'));
  const s = $('c' + i); if (s) { s.classList.add('on'); s.scrollIntoView({ block: 'center' }); }
}

// ---------- áudio (voz nativa + serviço em primeiro plano) ----------
async function fgStart() {
  if (!native) return;
  try {
    await ForegroundService.requestPermissions();
    await ForegroundService.startForegroundService({
      id: 1, title: 'Leitor', body: name + ' — pág. ' + (cur + 1), smallIcon: 'ic_launcher_foreground',
      silent: true, notificationChannelId: 'leitor',
      buttons: [{ id: 1, title: 'Pausar' }, { id: 2, title: 'Parar' }],
    });
  } catch (e) {}
}
async function fgStop() { if (native) try { await ForegroundService.stopForegroundService(); } catch (e) {} }
if (native) ForegroundService.addListener('buttonClicked', (ev) => (ev.buttonId === 1 ? pause() : stop()));

async function readFrom(start) {
  const my = ++run; playing = true; $('play').textContent = '⏸ Pausar';
  await fgStart();
  while (playing && my === run) {
    chunks = split(pages[cur] || ''); ci = start; start = 0;
    const rate = +$('rate').value, voice = $('vz').value === '' ? undefined : +$('vz').value;
    // enfileira a página inteira de uma vez: o Android continua falando mesmo com a tela bloqueada
    const jobs = chunks.slice(ci).map((c, k) =>
      TextToSpeech.speak({ text: c, lang: 'pt-BR', rate, voice, queueStrategy: 1 })
        .then(() => { if (my === run) { ci = ci + 1; mark(ci); } }).catch(() => {}));
    mark(ci);
    await Promise.all(jobs);
    if (my !== run || !playing) return;
    if (cur >= pages.length - 1) break;
    cur++; show();
    if (native) try { await ForegroundService.updateForegroundService({ id: 1, title: 'Leitor', body: name + ' — pág. ' + (cur + 1), smallIcon: 'ic_launcher_foreground', silent: true, notificationChannelId: 'leitor', buttons: [{ id: 1, title: 'Pausar' }, { id: 2, title: 'Parar' }] }); } catch (e) {}
  }
  if (my === run) await stop();
}
async function pause() { run++; playing = false; try { await TextToSpeech.stop(); } catch (e) {} $('play').textContent = '▶ Continuar'; }
async function stop() { run++; playing = false; try { await TextToSpeech.stop(); } catch (e) {} $('play').textContent = '▶ Ouvir'; await fgStop(); }
$('play').onclick = () => (playing ? pause() : readFrom($('play').textContent.includes('Continuar') ? ci : 0));
$('stop').onclick = stop;
async function go(d) { const was = playing; await stop(); cur = Math.max(0, Math.min(pages.length - 1, cur + d)); show(); if (was) readFrom(0); }
$('pv').onclick = () => go(-1); $('nx').onclick = () => go(1);

// ---------- IA (API da Anthropic) ----------
$('key').value = localStorage.getItem('key') || '';
$('savek').onclick = () => { localStorage.setItem('key', $('key').value.trim()); $('savek').textContent = 'Salva ✓'; };
const P = {
  resumo: 'Faça um resumo claro em português, em tópicos curtos.',
  resenha: 'Escreva uma resenha crítica em português: tese central, pontos fortes, limitações e para quem serve.',
  cards: "Crie 8 flashcards em português no formato 'P: ...' e 'R: ...'.",
  quiz: 'Crie um quiz de 5 questões de múltipla escolha em português, com o gabarito no final.',
};
async function ai(prompt) {
  const o = $('out'), key = localStorage.getItem('key');
  if (!key) { o.textContent = 'Salve sua chave da API abaixo primeiro.'; return; }
  const text = ($('sc').value === 'page' ? pages[cur] : pages.join('\n\n')).slice(0, 14000);
  o.textContent = 'Pensando…';
  try {
    const r = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'content-type': 'application/json', 'x-api-key': key, 'anthropic-version': '2023-06-01', 'anthropic-dangerous-direct-browser-access': 'true' },
      body: JSON.stringify({ model: MODEL, max_tokens: 2000, messages: [{ role: 'user', content: `Você é um assistente de estudo. Texto do PDF:\n"""\n${text}\n"""\n\n${prompt}` }] }),
    });
    const j = await r.json();
    o.textContent = j.content ? j.content.map((c) => c.text || '').join('') : 'Erro: ' + (j.error?.message || r.status);
  } catch (e) { o.textContent = 'Erro de rede.'; }
}
document.querySelectorAll('[data-k]').forEach((b) => (b.onclick = () => ai(P[b.dataset.k])));
$('ask').onclick = () => { const q = $('q').value.trim(); if (q) ai('Responda com base no texto: ' + q); };
